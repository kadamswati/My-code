# CORE.3D.jspkg
* 3D viewer, javascript web library, npm package
* This is the library module for the 3d viewer. 
* Installation command : `npm i @ttcorestudio/viewer_3d`

## Getting Started :  
* https://github.com/tt-acm/CORE.3D.jspkg/wiki/Getting-Started 

## API Functionality :
* https://github.com/tt-acm/CORE.3D.jspkg/wiki/API-Functionality 