# CORE.DataVis.jspkg

Data viewer, javascript web library, npm package

This is the library module for the data viewer.

Installation command : npm i @ttcorestudio/viewer_data
