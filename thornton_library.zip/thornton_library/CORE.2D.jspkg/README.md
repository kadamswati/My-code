# CORE.2D.jspkg
* 2D viewer, javascript web library, npm package
* This is the library module for the 2D viewer. 
* Installation command : `npm i @ttcorestudio/viewer_2d`
## Getting Started :  
* https://github.com/tt-acm/CORE.2D.jspkg/wiki/Getting-Started 
## 2D Viewer Library APIs :
* https://github.com/tt-acm/CORE.2D.jspkg/wiki/2D-Viewer-Library-APIs
