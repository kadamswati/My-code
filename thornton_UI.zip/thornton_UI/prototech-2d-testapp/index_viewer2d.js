import { Viewer } from '/node_modules/@ttcorestudio/viewer_2d/library_files/Viewer.js'
import { FileLoader } from '/node_modules/@ttcorestudio/viewer_2d/library_files/FileLoader.js'

init()

var viewerInstance, canvas;

function init() {
    var multiSelectionFlag = false;
    var highlightElementFlag = false;
    var selectedElementArray = [];

    canvas = document.getElementById('canvas');
    var chooseFileButton = document.getElementById('get_file');
    var multiselection_btn = document.getElementById('multiselection_btn');
    var clearSelection_btn = document.getElementById('clearSelection_btn');
    var highlightElement_btn = document.getElementById('highlightElement_btn');

    // viewer instance
    var defaultParams3dViewer = {
        backgroundColor: 0x00ff00,
        hightlightColor: 0xff00ff,
        axisTriad: true
    }

    var defaultParams2dViewer = {
        backgroundColor: "#00ff00",
        hightlightColor: "#ff00ff",
        axisTriad: true
    }

    // viewer instance
    viewerInstance = new Viewer();
    viewerInstance.addViewer(canvas);

    // register event listners
    viewerInstance.registerEvent('element-select', (elementID) => {
        console.log('Select :', elementID);
    });
    viewerInstance.registerEvent('element-highlight', (elementID) => {
        console.log('Highlight :', elementID);
    });

    // fileLoader instances
    var fileLoader = new FileLoader(viewerInstance);

    //adding model environment 
    fileLoader.modelScene();

    // select file to load in viewer
    chooseFileButton.onclick = function () {
        document.getElementById('my_file').click();
        document.getElementById('my_file').onchange = (event) => {
            fileLoader.addModel(event.target.files)
        }
    }

    // multiple or single element selection
    multiselection_btn.onclick = function (event) {
        multiSelectionFlag = !multiSelectionFlag;
        viewerInstance.clear_pickSelection();

        if (multiSelectionFlag == true) {
            multiselection_btn.style.backgroundColor = '#080';
            multiselection_btn.style.color = '#fff';
            viewerInstance.multiSelection(multiSelectionFlag);
        }
        else {
            multiselection_btn.style.backgroundColor = '#fff';
            multiselection_btn.style.color = '#000';
            viewerInstance.multiSelection(multiSelectionFlag);
        }
    }

    // highlight element
    highlightElement_btn.onclick = function (event) {
        highlightElementFlag = !highlightElementFlag;
        viewerInstance.clear_highlightSelection();
        if (highlightElementFlag == true) {
            highlightElement_btn.style.backgroundColor = '#080';
            highlightElement_btn.style.color = '#fff';
            viewerInstance.highlightCheck(true);
        }
        else {
            highlightElement_btn.style.backgroundColor = '#fff';
            highlightElement_btn.style.color = '#000';
            viewerInstance.highlightCheck(false);
        }
    }

    // get selected element array
    getSelected_btn.onclick = function (event) {
        selectedElementArray = viewerInstance.getSelected();
        console.log('Array of selected elements : ', selectedElementArray);
    }

    // clear the selection
    clearSelection_btn.onclick = function (event) {
        viewerInstance.clear_pickSelection();
        viewerInstance.clear_highlightSelection();
    }
    
    multiple_model_btn.onclick = function (event) {
        viewerInstance.multipleModelPosition();
    }

    document.getElementById('testAPI_btn').onclick = function (event) {
        viewerInstance.selectElements(['g847699f7-fed2-484e-840a-21f7c9c56bad-00056008', 'g-2000029']);
    }

}