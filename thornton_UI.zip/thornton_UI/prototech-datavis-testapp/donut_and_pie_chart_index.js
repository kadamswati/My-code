import plotMgrInstance from '/node_modules/@ttcorestudio/viewer_data/library_files/PlotMgr.js'

init()

function init() {
    var multipleSelectionFlag = false;
    var highlightElementFlag = false;
    var highlightElement_btn = document.getElementById('highlightElement_btn');
    var multipleSelection_btn = document.getElementById('multipleSelection_btn');

    var newData = [{
        'ellipseId': 'e-f9c62406-7c50-11d5-93b8-0000863f27ad-00002010',
        'Category': '',
        'Callout Tag': 'Callout Head w 3mm Corner Radius',
        'Elevation Tag': '12mm Circle',
        'Reference Label': '',
        'Design Option': '-1',
        'New views are dependent on template': 'Yes',
        'View Template applied to new views': '',
        'Family Name': '',
        'Type Name': '',
        'Referencing Sheet': '',
        'Family and Type': 'Elevation: Building Elevation',
        'Type Id': '49557',
        'Detail Number': '',
        'Type': 'Building Elevation',
        'Sheet Number': '',
        'Referencing Detail': '',
        'View Name': '',
        'Family': 'Elevation',
        'number': 10,
        'string': 'One',
        'date': '12-10-2022',
        'bool': true
    }, {
        'ellipseId': 'e-f9c62406-7c50-11d5-93b8-0000863f27ad-00001fd8',
        'Category': '',
        'Callout Tag': 'Callout Head w 3mm Corner Radius',
        'Elevation Tag': '12mm Circle',
        'Reference Label': '',
        'Design Option': '-1',
        'New views are dependent on template': 'Yes',
        'View Template applied to new views': '',
        'Family Name': '',
        'Type Name': '',
        'Show Hidden Lines': 'By Discipline',
        'None': '103653',
        'Far Clip Offset': '72.6127824805339',
        'Sheet Name': '',
        'Far Clipping': '',
        'Family and Type': 'Elevation: Building Elevation',
        'Crop Region Visible': 'No',
        'Sheet Number': '',
        'Display Model': 'Normal',
        'Detail Level': 'Coarse',
        'Color Scheme Location': 'Background',
        'Family': 'Elevation',
        'Title on Sheet': '',
        'Parts Visibility': 'Show Original',
        'View Scale': ' 1 : 50',
        'Default Analysis Display Style': 'None',
        'Sun Path': 'No',
        'Associated Datum': 'None',
        'Type Id': '49557',
        'Dependency': '',
        'Phase': 'New Construction',
        'Crop View': 'No',
        'Detail Number': '',
        'Scale Value    1:': '50',
        'Type': 'Building Elevation',
        'View Name': '',
        'Phase Filter': 'Show All',
        'Hide at scales coarser than': ' 1 : 5000',
        'Discipline': 'Architectural',
        'Referencing Detail': '',
        'View Template': '',
        'Rotation on Sheet': 'None',
        'Annotation Crop': 'No',
        'Scope Box': 'None',
        'Referencing Sheet': '',
        'number': 50,
        'string': 'Two',
        'date': '13-10-2022',
        'bool': false
    }, {
        'ellipseId': 'e-f9c62406-7c50-11d5-93b8-0000863f27ad-00001fee',
        'Category': '',
        'Callout Tag': 'Callout Head w 3mm Corner Radius',
        'Elevation Tag': '12mm Circle',
        'Reference Label': '',
        'Design Option': '-1',
        'New views are dependent on template': 'Yes',
        'View Template applied to new views': '',
        'Family Name': '',
        'Type Name': '',
        'Referencing Sheet': '',
        'Detail Number': '',
        'View Name': '',
        'Family': 'Elevation',
        'Type': 'Building Elevation',
        'Sheet Number': '',
        'Referencing Detail': '',
        'Type Id': '49557',
        'Family and Type': 'Elevation: Building Elevation',
        'number': 80,
        'string': 'Three',
        'date': '14 - 10 - 2022',
        'bool': true
    }, {
        'ellipseId': 'e-f9c62406-7c50-11d5-93b8-0000863f27ad-00001fef',
        'Category': '',
        'Callout Tag': 'Callout Head w 3mm Corner Radius',
        'Elevation Tag': '12mm Circle',
        'Reference Label': '',
        'Design Option': '-1',
        'New views are dependent on template': 'Yes',
        'View Template applied to new views': '',
        'Family Name': '',
        'Type Name': '',
        'Far Clipping': '',
        'Detail Number': '',
        'Detail Level': 'Coarse',
        'Sun Path': 'No',
        'View Scale': ' 1 : 50',
        'Family and Type': 'Elevation: Building Elevation',
        'Type': 'Building Elevation',
        'Far Clip Offset': '88.1699462256972',
        'Discipline': 'Architectural',
        'Phase Filter': 'Show All',
        'Sheet Number': '',
        'Phase': 'New Construction',
        'View Name': '',
        'Crop View': 'No',
        'Sheet Name': '',
        'Parts Visibility': 'Show Original',
        'Title on Sheet': '',
        'Dependency': '',
        'Display Model': 'Normal',
        'None': '103654',
        'Hide at scales coarser than': ' 1 : 5000',
        'View Template': '',
        'Annotation Crop': 'No',
        'Associated Datum': 'None',
        'Scope Box': 'None',
        'Referencing Detail': '',
        'Scale Value    1:': '50',
        'Type Id': '49557',
        'Crop Region Visible': 'No',
        'Rotation on Sheet': 'None',
        'Show Hidden Lines': 'By Discipline',
        'Family': 'Elevation',
        'Default Analysis Display Style': 'None',
        'Referencing Sheet': '',
        'Color Scheme Location': 'Background',
        'number': 100,
        'string': 'Four',
        'date': '15 - 10 - 2022',
        'bool': true
    },
    ]

    // donut chart
    var customSettingsForDonutPlot = {
        backgroundColor: '#9d9d9d',
        labelColor: '#000',
        selectionColor: '#ff00ff',
        outlineColor: 'red',
        highlightOpacity: 0.3,
        colorScheme: 'categorical',
        innerRadiusOfDonutChart: 55,
        outerRadiusOfDonutChart: 160
    }

    var customSettingsForDonutPlot1 = {
        backgroundColor: '#cee5b7',
        labelColor: '#00f',
        selectionColor: '#ff00ff',
        outlineColor: 'blue',
        highlightOpacity: 0.3,
        colorScheme: 'sequential',
        innerRadiusOfDonutChart: 45,
        outerRadiusOfDonutChart: 100
    }

    var plotInstance, canvas;
    canvas = document.getElementById('canvas');
    var response = plotMgrInstance.addDonutPlotInstance(canvas, 'canvas', customSettingsForDonutPlot);
    if (response['status'] == 'success') {
        plotInstance = plotMgrInstance.getDonutPlotByName('canvas');
        plotInstance.registerEvent('element-select', (elementID) => {
            console.log('Select :', elementID);
            plotMgrInstance.selectElementsInAllPlots(elementID);
        });
        plotInstance.registerEvent('element-highlight', (elementID) => { console.log('Highlight :', elementID); });
        plotInstance.addDonutPlot(newData, 'number', 'value');
    }

    var plotInstance1, canvas1;
    canvas1 = document.getElementById('canvas1');
    response = plotMgrInstance.addDonutPlotInstance(canvas1, 'canvas1', customSettingsForDonutPlot1);
    if (response['status'] == 'success') {
        plotInstance1 = plotMgrInstance.getDonutPlotByName('canvas1');
        plotInstance1.registerEvent('element-select', (elementID) => {
            console.log('Select :', elementID);
            plotMgrInstance.selectElementsInAllPlots(elementID);
        });
        plotInstance1.registerEvent('element-highlight', (elementID) => { console.log('Highlight :', elementID); });
        plotInstance1.addDonutPlot(newData, 'string', String);
    }

    var plotInstance2, canvas2;
    canvas2 = document.getElementById('canvas2');
    response = plotMgrInstance.addDonutPlotInstance(canvas2, 'canvas2');
    if (response['status'] == 'success') {
        plotInstance2 = plotMgrInstance.getDonutPlotByName('canvas2');
        plotInstance2.registerEvent('element-select', (elementID) => {
            console.log('Select :', elementID);
            plotMgrInstance.selectElementsInAllPlots(elementID);
        });
        plotInstance2.registerEvent('element-highlight', (elementIDs) => { console.log('Highlight :', elementIDs); });
        plotInstance2.addDonutPlot(newData, 'bool', 'count');
    }

    // pie chart
    var customSettingsForPiePlot = {
        backgroundColor: '#0cffd5',
        labelColor: '#000',
        selectionColor: '#ff00ff',
        outlineColor: 'black',
        highlightOpacity: 0.3,
        colorScheme: 'categorical',
        outerRadiusOfPieChart: 160
    }

    var customSettingsForPiePlot1 = {
        backgroundColor: '#759cc6',
        labelColor: '#00f',
        selectionColor: '#ff00ff',
        outlineColor: 'red',
        highlightOpacity: 0.3,
        colorScheme: 'sequential',
        outerRadiusOfPieChart: 100
    }

    var plotInstance3, canvas3;
    canvas3 = document.getElementById('canvas3');
    var response = plotMgrInstance.addPiePlotInstance(canvas3, 'canvas3', customSettingsForPiePlot);
    if (response['status'] == 'success') {
        plotInstance3 = plotMgrInstance.getPiePlotByName('canvas3');
        plotInstance3.registerEvent('element-select', (elementID) => {
            console.log('Select :', elementID);
            plotMgrInstance.selectElementsInAllPlots(elementID);
        });
        plotInstance3.registerEvent('element-highlight', (elementID) => { console.log('Highlight :', elementID); });
        plotInstance3.addPiePlot(newData, 'number', 'value');
    }

    var plotInstance4, canvas4;
    canvas4 = document.getElementById('canvas4');
    response = plotMgrInstance.addPiePlotInstance(canvas4, 'canvas4', customSettingsForPiePlot1);
    if (response['status'] == 'success') {
        plotInstance4 = plotMgrInstance.getPiePlotByName('canvas4');
        plotInstance4.registerEvent('element-select', (elementID) => {
            console.log('Select :', elementID);
            plotMgrInstance.selectElementsInAllPlots(elementID);
        });
        plotInstance4.registerEvent('element-highlight', (elementID) => { console.log('Highlight :', elementID); });
        plotInstance4.addPiePlot(newData, 'string', String);
    }

    var plotInstance5, canvas5;
    canvas5 = document.getElementById('canvas5');
    response = plotMgrInstance.addPiePlotInstance(canvas5, 'canvas5');
    if (response['status'] == 'success') {
        plotInstance5 = plotMgrInstance.getPiePlotByName('canvas5');
        plotInstance5.registerEvent('element-select', (elementID) => {
            console.log('Select :', elementID);
            plotMgrInstance.selectElementsInAllPlots(elementID);
        });
        plotInstance5.registerEvent('element-highlight', (elementIDs) => { console.log('Highlight :', elementIDs); });
        plotInstance5.addPiePlot(newData, 'bool', 'count');
    }

    // multiple selection
    multipleSelection_btn.onclick = function (event) {
        multipleSelectionFlag = !multipleSelectionFlag;
        plotMgrInstance.deselectElementsInAllPlots();

        if (multipleSelectionFlag == true) {
            multipleSelection_btn.style.backgroundColor = '#080';
            multipleSelection_btn.style.color = '#fff';
            plotInstance.multipleSelectionCheck(true);
            plotInstance1.multipleSelectionCheck(true);
            plotInstance2.multipleSelectionCheck(true);
            plotInstance3.multipleSelectionCheck(true);
            plotInstance4.multipleSelectionCheck(true);
            plotInstance5.multipleSelectionCheck(true);
        }
        else {
            multipleSelection_btn.style.backgroundColor = '#fff';
            multipleSelection_btn.style.color = '#000';
            plotInstance.multipleSelectionCheck(false);
            plotInstance1.multipleSelectionCheck(false);
            plotInstance2.multipleSelectionCheck(false);
            plotInstance3.multipleSelectionCheck(false);
            plotInstance4.multipleSelectionCheck(false);
            plotInstance5.multipleSelectionCheck(false);
        }
    }

    // highlight element
    highlightElement_btn.onclick = function (event) {
        highlightElementFlag = !highlightElementFlag;
        if (highlightElementFlag == true) {
            highlightElement_btn.style.backgroundColor = '#080';
            highlightElement_btn.style.color = '#fff';
            plotInstance.highlightCheck(true);
            plotInstance1.highlightCheck(true);
            plotInstance2.highlightCheck(true);
            plotInstance3.highlightCheck(true);
            plotInstance4.highlightCheck(true);
            plotInstance5.highlightCheck(true);
        }
        else {
            highlightElement_btn.style.backgroundColor = '#fff';
            highlightElement_btn.style.color = '#000';
            plotInstance.highlightCheck(false);
            plotInstance1.highlightCheck(false);
            plotInstance2.highlightCheck(false);
            plotInstance3.highlightCheck(false);
            plotInstance4.highlightCheck(false);
            plotInstance5.highlightCheck(false);
        }
    }

    document.getElementById('clearPlot_btn').onclick = function (event) {
        plotMgrInstance.clearPiePlotByName('canvas1');
    }
    document.getElementById('clearAllPlot_btn').onclick = function (event) {
        plotMgrInstance.clearAllPiePlots();
    }

    document.getElementById('deSelectElements_btn').onclick = function (event) {
        plotMgrInstance.deselectElementsInAllPlots();
    }
}