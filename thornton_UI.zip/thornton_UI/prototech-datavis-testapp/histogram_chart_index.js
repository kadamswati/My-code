import plotMgrInstance from '/node_modules/@ttcorestudio/viewer_data/library_files/PlotMgr.js'
init()

function init() {
    let multipleSelectionFlag = false;
    let multipleSelection_btn = document.getElementById('multipleSelection_btn');
    let highlightElementFlag = false;
    let highlightElement_btn = document.getElementById('highlightElement_btn');
    let addPlotFlag = false;
    let addModel_btn = document.getElementById('addModel_btn');

    let newData = [
        {
            "uuid": "01a3031b-eecc-4eea-9699-97342102d866",
            "Layer": "Sidewalks",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": ""
        },
        {
            "uuid": "09303ac2-1467-4bfa-8175-3ca7f27bdd7d",
            "Layer": "Sidewalks",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": ""
        },
        {
            "uuid": "0b59b1e3-7894-4f1b-b172-b486c9a5a7ff",
            "Layer": "Sidewalks",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": ""
        },
        {
            "uuid": "0eefbd5f-af53-46dd-8d1d-5bdc9eb57c7c",
            "Layer": "Sidewalks",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": ""
        },
        {
            "uuid": "1eec66c6-e209-493e-a292-aba6a7cf3f53",
            "Layer": "Sidewalks",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": ""
        },
        {
            "uuid": "217f26dc-597b-4821-a272-e6120173bdaa",
            "Layer": "Sidewalks",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": ""
        },
        {
            "uuid": "2581f01d-aa92-460f-a530-7f85b7029897",
            "Layer": "Park",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": ""
        },
        {
            "uuid": "2a8cdb9e-6f28-40b4-ad51-af110f200782",
            "Layer": "Park",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": ""
        },
        {
            "uuid": "3e0b21dd-8eda-4596-9131-3239d588548f",
            "Layer": "Park",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": ""
        },
        {
            "uuid": "3ec6d2b1-ea65-4068-a334-36e4b5554e20",
            "Layer": "Park",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": ""
        },
        {
            "uuid": "44ce2e0c-9be1-4dd4-810c-4cc71923ded0",
            "Layer": "Sidewalks",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": ""
        },
        {
            "uuid": "50d6dc37-9d49-4f04-b0fc-299149ab9903",
            "Layer": "Sidewalks",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": ""
        },
        {
            "uuid": "533c6711-90e2-44f8-84c1-da9ac79b9db8",
            "Layer": "Sidewalks",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": ""
        },
        {
            "uuid": "65ad9571-b613-495b-9be3-32777e0bd55d",
            "Layer": "Park",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": ""
        },
        {
            "uuid": "68e4bf76-6a45-417a-bcc3-8f205e52828a",
            "Layer": "Sidewalks",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": ""
        },
        {
            "uuid": "70f2143e-0cdd-4697-85be-9c6dab4ef745",
            "Layer": "Sidewalks",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": ""
        },
        {
            "uuid": "75cc4c15-bb06-437e-a7ec-fc688b8b0152",
            "Layer": "Sidewalks",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": ""
        },
        {
            "uuid": "8dd765dc-d235-49de-b0fd-3773fb73dae4",
            "Layer": "Sidewalks",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": ""
        },
        {
            "uuid": "958ab4df-a678-4518-9cba-382c08af3810",
            "Layer": "Sidewalks",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": ""
        },
        {
            "uuid": "99f4a0d5-e1d4-4de2-beac-24593ce9a24a",
            "Layer": "Sidewalks",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": ""
        },
        {
            "uuid": "9b0ccc49-7970-4d66-9a46-5151db8bd21b",
            "Layer": "Sidewalks",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": ""
        },
        {
            "uuid": "9db773f7-9135-4fcb-a178-acc39720febc",
            "Layer": "Sidewalks",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": ""
        },
        {
            "uuid": "9e0444e1-699e-4447-8bc6-7736972b71c5",
            "Layer": "Sidewalks",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": ""
        },
        {
            "uuid": "9e57b7eb-b507-49be-bab8-1fbc2c270dd2",
            "Layer": "Sidewalks",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": ""
        },
        {
            "uuid": "a0523721-c052-4b21-aa6b-7a2f300e0419",
            "Layer": "Sidewalks",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": ""
        },
        {
            "uuid": "a3f02794-ca4c-43a5-b661-68cf46d7b414",
            "Layer": "Sidewalks",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": ""
        },
        {
            "uuid": "aebd68a2-8802-46d7-803f-d57bb61ef19c",
            "Layer": "Sidewalks",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": ""
        },
        {
            "uuid": "b0f749d9-5e15-46bb-a870-53dafb6928ed",
            "Layer": "Sidewalks",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": ""
        },
        {
            "uuid": "cde0fdaa-67d5-469e-a94a-b1fbc6f34be6",
            "Layer": "Roads",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": ""
        },
        {
            "uuid": "d85915b1-cd45-4123-ae56-4d03cf57b66b",
            "Layer": "Park",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": ""
        },
        {
            "uuid": "da4ee8b2-cf7b-42e3-b336-f75c2751c229",
            "Layer": "Sidewalks",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": ""
        },
        {
            "uuid": "dd8f5b7a-02bf-4a1c-811e-9f9c5f8b3454",
            "Layer": "Sidewalks",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": ""
        },
        {
            "uuid": "f12c9430-378e-4e01-868e-f66931a8a8c4",
            "Layer": "Sidewalks",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": false
        },
        {
            "uuid": "fc298b30-3d87-45d5-8b33-e78b0422f35b",
            "Layer": "Sidewalks",
            "Building No": "",
            "Construction Type": "",
            "Lot No-": "",
            "Phase": "",
            "Program": "",
            "Floor No-": "",
            "Floor Height": "",
            "Floorplate Area": "",
            "GFA": "",
            "No- Floors": "",
            "Building Height": "",
            "Ground Floor Area": "",
            "bool": false
        },
        {
            "uuid": "0012da10-e8d8-462c-8d24-5e67e97453b3",
            "Layer": "Hotel",
            "Building No": 18,
            "Construction Type": 6,
            "Lot No-": 11,
            "Phase": 4,
            "Program": "Hotel",
            "Floor No-": 10,
            "Floor Height": 110,
            "Floorplate Area": 9627,
            "GFA": 152960,
            "No- Floors": 18,
            "Building Height": 200,
            "Ground Floor Area": 9627,
            "bool": true
        },
        {
            "uuid": "0055628c-cdff-4286-87a1-dac6fa6b5167",
            "Layer": "Retail",
            "Building No": 28,
            "Construction Type": 6,
            "Lot No-": 20,
            "Phase": 8,
            "Program": "Retail",
            "Floor No-": 1,
            "Floor Height": 0,
            "Floorplate Area": 79790,
            "GFA": 800051,
            "No- Floors": 24,
            "Building Height": 312,
            "Ground Floor Area": 79790,
            "bool": true
        },
        {
            "uuid": "00593b96-e0de-44d3-8f10-2256f3a5d893",
            "Layer": "Resi",
            "Building No": 22,
            "Construction Type": 5,
            "Lot No-": 5,
            "Phase": 4,
            "Program": "Residential",
            "Floor No-": 2,
            "Floor Height": 15,
            "Floorplate Area": 12100,
            "GFA": 350900,
            "No- Floors": 29,
            "Building Height": 300,
            "Ground Floor Area": 12100,
            "bool": false
        },
        {
            "uuid": "00cf4eee-284e-4d90-86b4-e47d99dec4cb",
            "Layer": "Resi",
            "Building No": 35,
            "Construction Type": 2,
            "Lot No-": 25,
            "Phase": 5,
            "Program": "Residential",
            "Floor No-": 4,
            "Floor Height": 40,
            "Floorplate Area": 11038,
            "GFA": 206515,
            "No- Floors": 16,
            "Building Height": 170,
            "Ground Floor Area": 25991,
            "bool": true
        },
        {
            "uuid": "0122ee52-9f25-4ac7-9d6d-bdd2c4a1a3f3",
            "Layer": "Resi",
            "Building No": 11,
            "Construction Type": 2,
            "Lot No-": 2,
            "Phase": 2,
            "Program": "Residential",
            "Floor No-": 17,
            "Floor Height": 170,
            "Floorplate Area": 11736,
            "GFA": 340336,
            "No- Floors": 29,
            "Building Height": 300,
            "Ground Floor Area": 11736,
            "bool": false
        },
        {
            "uuid": "017baa9e-4227-4964-8a96-aa9298597396",
            "Layer": "Office",
            "Building No": 9,
            "Construction Type": 6,
            "Lot No-": 9,
            "Phase": 2,
            "Program": "Office",
            "Floor No-": 10,
            "Floor Height": 119,
            "Floorplate Area": 10207,
            "GFA": 217933,
            "No- Floors": 18,
            "Building Height": 230,
            "Ground Floor Area": 18340,
            "bool": false
        },
        {
            "uuid": "01c55949-9da2-4c8c-b15b-c2f98f807bf2",
            "Layer": "Hotel",
            "Building No": 23,
            "Construction Type": 6,
            "Lot No-": 5,
            "Phase": 4,
            "Program": "Hotel",
            "Floor No-": 11,
            "Floor Height": 120,
            "Floorplate Area": 27148,
            "GFA": 352926,
            "No- Floors": 13,
            "Building Height": 150,
            "Ground Floor Area": 27148,
            "bool": false
        },
        {
            "uuid": "01d499d0-8975-49ed-b8c3-25783f0b1307",
            "Layer": "Retail",
            "Building No": 2,
            "Construction Type": 6,
            "Lot No-": 10,
            "Phase": 3,
            "Program": "Retail",
            "Floor No-": 2,
            "Floor Height": 15,
            "Floorplate Area": 47638,
            "GFA": 600721,
            "No- Floors": 30,
            "Building Height": 370,
            "Ground Floor Area": 47638,
            "bool": true
        },
        {
            "uuid": "01fb16a2-a49b-4462-a475-fb58d485d8b3",
            "Layer": "Resi",
            "Building No": 22,
            "Construction Type": 5,
            "Lot No-": 5,
            "Phase": 4,
            "Program": "Residential",
            "Floor No-": 18,
            "Floor Height": 180,
            "Floorplate Area": 12100,
            "GFA": 350900,
            "No- Floors": 29,
            "Building Height": 300,
            "Ground Floor Area": 12100,
            "bool": true
        }]

    let defaultParamsHistogramPlot = {
        backgroundColor: "#a1a1a1",
        axisColor: "blue",
        histogramBarColor: "#ff765b",
        selectionColor: "#ff00ff",
        highlightOpacity: 0.3,
        XAxisDomainRange: [0, 10],
        BinsValue: 5
    }

    let plotInstance, canvas;
    canvas = document.getElementById('canvas');
    let response = plotMgrInstance.addHistogramPlotInstance(canvas, 'canvas');
    if (response['status'] == 'success') {
        plotInstance = plotMgrInstance.getHistogramPlotByName('canvas');
        plotInstance.registerEvent('element-select', (elementID) => {
            console.log('Select :', elementID);
            plotMgrInstance.selectElementsInAllPlots(elementID);
        });
        plotInstance.registerEvent('element-highlight', (elementID) => {
            console.log('Highlight :', elementID);
            plotMgrInstance.highlightElementsInAllPlots(elementID);
        });
    }

    let plotInstance1, canvas1;
    canvas1 = document.getElementById('canvas1');
    response = plotMgrInstance.addHistogramPlotInstance(canvas1, 'canvas1', defaultParamsHistogramPlot);
    if (response['status'] == 'success') {
        plotInstance1 = plotMgrInstance.getHistogramPlotByName('canvas1');
        plotInstance1.registerEvent('element-select', (elementID) => {
            console.log('Select :', elementID);
            plotMgrInstance.selectElementsInAllPlots(elementID);
        });
        plotInstance1.registerEvent('element-highlight', (elementID) => {
            console.log('Highlight :', elementID);
            plotMgrInstance.highlightElementsInAllPlots(elementID);
        });
    }

    // add model
    addModel_btn.onclick = function (event) {
        addPlotFlag = !addPlotFlag;
        if (addPlotFlag == true) {
            addModel_btn.style.backgroundColor = '#080';
            addModel_btn.style.color = '#fff';
        }
        else {
            addModel_btn.style.backgroundColor = '#fff';
            addModel_btn.style.color = '#000';
        }
        plotInstance.addHistogramPlot(newData, 'uuid', 'Building No', 'value');
        plotInstance1.addHistogramPlot(newData, 'uuid', 'Phase', 'count');
    }

    // multiple selection
    multipleSelection_btn.onclick = function (event) {
        multipleSelectionFlag = !multipleSelectionFlag;
        plotMgrInstance.deSelectElementsInAllPlots();

        if (multipleSelectionFlag == true) {
            multipleSelection_btn.style.backgroundColor = '#080';
            multipleSelection_btn.style.color = '#fff';
            plotInstance.multipleSelectionCheck(true);
            plotInstance1.multipleSelectionCheck(true);
        }
        else {
            multipleSelection_btn.style.backgroundColor = '#fff';
            multipleSelection_btn.style.color = '#000';
            plotInstance.multipleSelectionCheck(false);
            plotInstance1.multipleSelectionCheck(false);
        }
    }

    // highlight element
    highlightElement_btn.onclick = function (event) {
        highlightElementFlag = !highlightElementFlag;
        if (highlightElementFlag == true) {
            highlightElement_btn.style.backgroundColor = '#080';
            highlightElement_btn.style.color = '#fff';
            plotInstance.highlightCheck(true);
            plotInstance1.highlightCheck(true);
        }
        else {
            highlightElement_btn.style.backgroundColor = '#fff';
            highlightElement_btn.style.color = '#000';
            plotInstance.highlightCheck(false);
            plotInstance1.highlightCheck(false);
        }
    }
    document.getElementById('clearPlot_btn').onclick = function (event) {
        plotMgrInstance.clearHistogramPlotByName('canvas');
    }
    document.getElementById('clearAllPlot_btn').onclick = function (event) {
        plotMgrInstance.clearAllHistogramPlots();
    }
}